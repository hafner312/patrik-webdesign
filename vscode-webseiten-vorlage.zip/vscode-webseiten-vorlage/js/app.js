const testButton = document.querySelector("#testButton");
const output = document.querySelector("#output");

testButton.addEventListener("click", () => {
  output.textContent = `JavaScript funktioniert. Zeitpunkt: ${new Date().toLocaleTimeString("de-CH")}`;
});
