# Projektanweisungen

- Dieses Projekt ist eine einfache HTML-, CSS- und JavaScript-Webseite.
- Zum Starten soll die vorhandene VS-Code-Debugkonfiguration verwendet werden.
- Die gewünschte Aktion ist **Ausführen > Debugging starten** oder **F5**.
- Die Webseite soll in einem separaten Google-Chrome-Fenster mit einem einzelnen Tab geöffnet werden.
- Keine zusätzlichen Browser-Tabs öffnen.
- Den lokalen Webserver über die vorhandene Aufgabe `Webserver starten` verwenden.
