# VS-Code-Webseitenvorlage

Diese Vorlage startet eine statische Webseite über **Ausführen > Debugging starten** oder **F5**.
VS Code startet dabei automatisch einen lokalen Webserver und öffnet die Seite in einem separaten Chrome-Fenster.
Durch das eigene Chrome-Profil wird die Debug-Sitzung von deinem normalen Chrome getrennt gehalten.

## Einmalige Einrichtung

1. Den Ordner in VS Code öffnen.
2. Im Terminal ausführen:

   ```bash
   npm install
   ```

3. Danach **F5** drücken oder **Ausführen > Debugging starten** auswählen.
4. Falls VS Code nach einer Konfiguration fragt, **Webseite in separatem Chrome starten** auswählen.

## Beenden

Mit **Umschalttaste + F5** wird das Debugging beendet. Das von VS Code gestartete Chrome-Fenster wird dabei geschlossen.

## Projektstruktur

- `index.html` – Startseite
- `css/style.css` – Gestaltung
- `js/app.js` – JavaScript
- `.vscode/launch.json` – Chrome-Debugkonfiguration
- `.vscode/tasks.json` – lokaler Webserver
- `.github/copilot-instructions.md` – Anweisung für die KI im Projekt

## Port ändern

Der Webserver verwendet Port `5500`. Falls dieser belegt ist, muss der Port an zwei Stellen geändert werden:

- `package.json` bei `-p 5500`
- `.vscode/launch.json` bei `http://localhost:5500`
